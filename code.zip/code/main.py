import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.linear_model import Lasso

from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error

## configurations
#### classification or regression?
TASK = "classification"

## start from the last line in the notebook
## drop the two unused columns
data = renamed_df_new.drop(columns = ["good_day_reason_1", "good_day_reason_2"])

## build the stress label, which is used for classification
data["stress_label"] = pd.cut(data["stress_level"], [-1, 40, 70, 101], labels = ["good", "normal", "stressed"])

## split the target columns and features
clf_tgt = data["stress_label"]
rgs_tgt = data["stress_level"]
data = data.drop(columns = ["stress_label", "stress_level"])

## one-hot encoding for string columns
data = pd.get_dummies(data)

## finalizing pre-processing
data["stress_level"] = rgs_tgt
data["stress_label"] = clf_tgt

## write the result to a csv
data.to_csv("data.csv", index = False)

## free memories
del clf_tgt
del rgs_tgt
del renamed_df_new
del data

## read the data
data = pd.read_csv("data.csv")

## prepare for machine learning
if TASK == "classification":
    y = data["stress_label"].to_numpy()
else:
    y = data["stress_level"].to_numpy()

data = data.drop(columns = ["stress_label", "stress_level"]).to_numpy()

x_train, x_test, y_train, y_test = train_test_split(data, y, test_size = 0.3)

if TASK == "classification":
    mdl = AdaBoostClassifier(n_estimators=100).fit(x_train, y_train)
    score = mdl.score(x_test, y_test)
else:
    mdl = Lasso(alpha=0.1).fit(x_train, y_train)
    mse = mean_squared_error(mdl.predict(x_test), y_test)
    mae = mean_absolute_error(mdl.predict(x_test), y_test)
